
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <button class="btn side-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a href="#">
                <img src="<?php echo e(url('/')); ?>/assets/imgs/logo.png" alt="" class="side-logo" />
            </a>
            <h1 class="page-title">Settings</h1>
        </div>
        <div class="head-control">          
            <?php echo $__env->make('layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>

    <div class="body-content">
        <?php echo $__env->make('message_error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('javascript_message_error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- mobile title -->
        <h1 class="page-title-sm">Settings</h1>

        <div class="border-bottom mb-3 pb-3"> 
        </div>
                
        <div class="card custom-border-card mt-3">
            <h5 class="card-header">Email Settings [SMTP]</h5>
            <div class="card-body">
                <form name="formSettings" id="formSettings" method="post" enctype="multipart/form-data" action="<?php echo e(route("admin.settings_smtp.save")); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php if($smtp): ?> <?php echo e($smtp->id); ?><?php endif; ?>">
                    <input type="hidden" name="app_id" value=<?php echo e(session::get('app_key')); ?>>
                    <div class="row col-lg-12">
                        <div class="form-group  col-lg-6">
                            <label for="status">IS SMTP Active</label>
                            <select name="status" class="form-control" id="status" required>
                                <option value="">Select Status</option>
                                <option value="1" <?php if($smtp && $smtp->status==1): ?> selected <?php endif; ?>>
                                Yes
                                </option>
                                <option value="0" <?php if($smtp && $smtp->status==0): ?> selected <?php endif; ?>>
                                No
                                </option>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="host">Host</label>
                            <input type="text" name="host" class="form-control" id="host" value="<?php if($smtp): ?><?php echo e($smtp->host); ?><?php endif; ?>" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="port">Port</label>
                            <input type="text" name="port" class="form-control" id="port" value="<?php if($smtp): ?><?php echo e($smtp->port); ?><?php endif; ?>" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="protocol">Protocol</label>
                            <input type="text" name="protocol" class="form-control" id="protocol" required placeholder="Enter Your protocol" value="<?php if($smtp): ?><?php echo e($smtp->protocol); ?><?php endif; ?>">
                        </div>
                    </div>
                    <div class="row col-lg-12">
                        <div class="form-group col-lg-6">
                            <label for="user">User name</label>
                            <input type="text" name="user" class="form-control" id="user" value="<?php if($smtp): ?><?php echo e($smtp->user); ?><?php endif; ?>" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="pass">Password</label>
                            <input type="password" name="pass" class="form-control" id="pass" value="<?php if($smtp): ?><?php echo e($smtp->pass); ?><?php endif; ?>" required>
                        </div>
                    </div>
                    <div class="row col-lg-12">
                        <div class="form-group col-lg-6">
                            <label for="from_name">From name</label>
                            <input type="text" name="from_name" class="form-control" id="from_name" value="<?php if($smtp): ?><?php echo e($smtp->from_name); ?><?php endif; ?>" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="from_email">From Email</label>
                            <input type="text" name="from_email" class="form-control" id="from_email" value="<?php if($smtp): ?><?php echo e($smtp->from_email); ?><?php endif; ?>" required>
                        </div>
                    </div>
                    <div class="border-top pt-3 text-right">
                        <button type="submit" class="btn btn-default mw-120">SAVE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(url("/")); ?>/js/jquery.minicolors.js"></script>
<link rel="stylesheet" href="<?php echo e(url("/")); ?>/css/jquery.minicolors.css">

<?php $__env->startSection('pagescript'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/admin/smtp.blade.php ENDPATH**/ ?>