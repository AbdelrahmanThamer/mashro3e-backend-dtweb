<!DOCTYPE html>
<html lang="zxx">
    <head>
        <!-- Meta Tag -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name='copyright' content=''>             
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Title Tag  -->
        <title><?php echo e(env('APP_NAME')); ?></title>
        <!-- Favicon -->
        <!--<link rel="icon" type="image/png" href="images/favicon.png">-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo e(url("/")); ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(url("/")); ?>/assets/css/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="<?php echo e(url("/")); ?>/style.css?v=<?php echo e(version()); ?>" rel="stylesheet">
        <link href="<?php echo e(url("/")); ?>/custom.css?v=<?php echo e(version()); ?>" rel="stylesheet">

        <!--Custom CSS-->
        <script>
            var globalSiteUrl = '<?php echo $path = url('/'); ?>'
            var serverEnvironment = '<?php echo env('APP_ENV'); ?>'
            var currentRouteName = '<?php echo request()->route()->getName(); ?>'
        </script>          
    </head>
    <body>

        <?php echo $__env->yieldContent('content'); ?>


        <!-- Jquery -->
        <script src="<?php echo e(url("/")); ?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo e(url("/")); ?>/assets/js/popper.min.js"></script>
        <script src="<?php echo e(url("/")); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo e(url("/")); ?>/assets/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(url("/")); ?>/assets/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo e(url("/")); ?>/assets/js/js.js?v=<?php echo e(version()); ?>"></script>


        <script src="<?php echo e(url("/")); ?>/js/jquery.validate.min.js"></script>        
        <script src="<?php echo e(url("/")); ?>/js/additional-methods.min.js"></script>  

        <?php echo $__env->yieldContent('pagescript'); ?>
    </body>
</html><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/layout/page-app.blade.php ENDPATH**/ ?>