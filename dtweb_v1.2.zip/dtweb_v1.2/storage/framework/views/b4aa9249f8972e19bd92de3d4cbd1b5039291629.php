
<?php $__env->startSection('content'); ?>

<div class="h-100">
    <div class="h-100 no-gutters row">
        <div class="d-none d-lg-block h-100 col-lg-5 col-xl-4">
            <div class="left-caption">
                <img src="assets/imgs/login.jpg" class="bg-img" />
                <div class="caption">
                    <div>
                        <!-- <h3>Login</h3> -->
                        <!-- logo -->
                        <a href="#">
                            <img src="assets/imgs/logo-white.png" alt="" class="img-fluid" />
                        </a>
                        <p class="text">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto quaerat fuga optio voluptatibus ullam
                            aliquam consectetur, quam, veritatis facilis dolor id perspiciatis distinctio ratione! Reprehenderit
                            rerum
                            provident vero praesentium molestiae?
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="h-100 d-flex login-bg justify-content-center align-items-lg-center col-md-12 col-lg-7 col-xl-8">
            <div class="mx-auto app-login-box col-sm-12 col-md-10 col-xl-8">
                <div class="py-5 p-3">

                    <!-- logo -->
                    <div class="app-logo mb-4">
                        <a href="#" class="mb-4 d-block d-lg-none">
                            <img src="assets/imgs/logo.png" alt="" class="img-fluid" />
                        </a>
                        <h3 class="primary-color mb-0 font-weight-bold">Login</h3>
                    </div>
                    <!-- end logo -->

                    <h4 class="mb-0 font-weight-bold">
                        <span class="d-block mb-2">Welcome back,</span>
                        <span>Please sign in to your account.</span>
                    </h4>
                    <!-- <h6 class="mt-3 border-bottom pb-3">No account? <a href="javascript:void(0);" class="text-primary">Sign up
                        now</a></h6>
                    <div> -->
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row mt-4">
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="exampleEmail" class="">Email</label>
                                    <input name="email" id="email" placeholder="Email here..." type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="admin@admin.com" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="examplePassword" class="">Password</label>
                                    <input name="password" id="password" placeholder="Password here..." type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="admin" required autocomplete="current-password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                            <input type="checkbox" class="custom-control-input" id="customControlAutosizing" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="customControlAutosizing">Keep me logged in</label>
                        </div>

                        <div class="form-row mt-4">
                            <div class="col-sm-6 text-center text-sm-left">
                                <button class="btn btn-default my-3 mw-120" type="submit">Login</button>
                            </div>
                            <!--                            <div class="col-sm-6 d-flex align-items-center justify-content-center justify-content-sm-end">
                                                            <a href="javascript:void(0);" class="btn-lg btn btn-link">Recover Password</a>
                                                        </div>-->
                        </div>

                        <!--                        <div class="row mb-0">
                                                    <div class="col-md-8 offset-md-4">
                                                        <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Login')); ?>

                                                        </button>
                        
                                                        <?php if(Route::has('password.request')): ?>
                                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                                            <?php echo e(__('Forgot Your Password?')); ?>

                                                        </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>-->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/auth/login.blade.php ENDPATH**/ ?>