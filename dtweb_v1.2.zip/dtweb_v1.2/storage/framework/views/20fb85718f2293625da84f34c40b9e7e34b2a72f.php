
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <button class="btn side-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a href="#">
                <img src="<?php echo e(url('/')); ?>/assets/imgs/logo.png" alt="" class="side-logo" />
            </a>
            <h1 class="page-title">Dashboard</h1>
        </div>
        <div class="head-control">
            <?php echo $__env->make('layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>
    <div class="body-content">
        <!-- mobile title -->
        <h1 class="page-title-sm">Dashboard</h1>

        <div class="row counter-row">
            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <a href="<?php echo e(route('admin.introduction')); ?>">
                    <div class="db-color-card">
                        <img src="<?php echo e(url('/')); ?>/assets/imgs/video-green.png" alt="" class="card-icon" />
                        <!--                    <div class="dropdown dropright">
                                                <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <img src="<?php echo e(url('/')); ?>/assets/imgs/dot.png" class="dot-icon" />
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                    <a class="dropdown-item" href="#">Action</a>
                                                    <a class="dropdown-item" href="#">Another action</a>
                                                    <a class="dropdown-item" href="#">Something else here</a>
                                                </div>
                                            </div>-->
                        <h2 class="counter">
                            <?php echo e($totalIntroScreen); ?>

                            <span>Total Welcome screen</span>
                        </h2>
                    </div>
                </a>
            </div>
            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <a href="<?php echo e(route('admin.menu')); ?>">
                    <div class="db-color-card cate-card">
                        <img src="<?php echo e(url('/')); ?>/assets/imgs/categories-purple.png" alt="" class="card-icon" />
                        <!--                    <div class="dropdown dropright">
                                                <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <img src="<?php echo e(url('/')); ?>/assets/imgs/dot.png" class="dot-icon" />
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                    <a class="dropdown-item" href="#">Action</a>
                                                    <a class="dropdown-item" href="#">Another action</a>
                                                    <a class="dropdown-item" href="#">Something else here</a>
                                                </div>
                                            </div>-->
                        <h2 class="counter">
                            <?php echo e($totalMenu); ?>

                            <span>Total Menu</span>
                        </h2>
                    </div>
                </a>
            </div>
            <div class="col-6 col-sm-4 col-md col-lg-4 col-xl">
                <a href="<?php echo e(route('admin.users')); ?>">
                    <div class="db-color-card user-card">
                        <img src="<?php echo e(url('/')); ?>/assets/imgs/user-brown.png" alt="" class="card-icon" />
                        <!--                    <div class="dropdown dropright">
                                                <a href="#" class="btn head-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <img src="<?php echo e(url('/')); ?>/assets/imgs/dot.png" class="dot-icon" />
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                    <a class="dropdown-item" href="#">Action</a>
                                                    <a class="dropdown-item" href="#">Another action</a>
                                                    <a class="dropdown-item" href="#">Something else here</a>
                                                </div>
                                            </div>-->
                        <h2 class="counter">
                            <?php echo e($totalUsers); ?>

                            <span>Total Register users</span>
                        </h2>
                    </div>
                </a>
            </div>


        </div>
        <div class="row">
            <div class="col-12 col-xl-9">
                <div class="box-title">
                    <h2 class="title">Recent Added Users</h2>
                    <a class="btn btn-link" href="<?php echo e(route('admin.users')); ?>">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>
                                    FullName
                                </th>
                                <th>
                                    Email/Number
                                </th>                               
                                <th>
                                    Type
                                </th>
                                <th>
                                    Created Date
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="clamp-text"><?php echo e($u->username); ?></span>
                                </td>
                                <td>
                                    <span class="clamp-text"><?php echo e($u->email); ?></span>
                                </td>                                
                                <td>
                                    <span class="clamp-text">
                                        <?php if($u->type == 1): ?>
                                            Mobile
                                        <?php elseif($u->type == 2): ?>
                                            Facebook
                                        <?php elseif($u->type == 3): ?>
                                            Gmail
                                        <?php elseif($u->type == 4): ?>
                                            Apple
                                        <?php endif; ?>
                                    </span>
                                </td>                                
                                <td>
                                    <?php echo e(date('d-M-Y h:i A',strtotime($u->created_at))); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script>
    $(document).ready(function () {
        $('#fileupload').change(function () {
            var html = '<button class="close" type="button"> <span aria-hidden="true">&times;</span></button>';
            html += '<img src="" id="idLogo"/>';
            $('#idMainLogo').html(html)
            var reader = new FileReader();
            reader.onload = function () {
                var output = document.getElementById('idLogo');
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        });


        $('#formSettings').validate({
            rules: {
                base_url: {
                    required: true,
                    url: true
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>