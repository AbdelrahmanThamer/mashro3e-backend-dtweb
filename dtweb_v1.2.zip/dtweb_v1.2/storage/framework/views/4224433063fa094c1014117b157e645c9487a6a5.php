<div class="alert alert-success alert-dismissible fade show msgHide" role="alert" id="idAlertSuccessMsg" style="display: none">
    <strong>Success!</strong> <span id="idScriptSuccessMsg"></span>    
    <button type="button" class="btn-close close closeSuccess" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="alert alert-danger alert-dismissible fade show msgHide" role="alert" id="idAlertErrorMsg" style="display: none">
    <strong>Error!</strong> <span id="idScriptErrorMsg"></span>
    <button class="btn-close close closeError" type="button"></button>
</div>

<?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/javascript_message_error_success.blade.php ENDPATH**/ ?>