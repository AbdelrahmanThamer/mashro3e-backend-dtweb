
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="right-content">
    <header class="header">
        <div class="title-control">
            <button class="btn side-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a href="#">
                <img src="<?php echo e(url('/')); ?>/assets/imgs/logo.png" alt="" class="side-logo" />
            </a>
            <h1 class="page-title">Introduction Screen List</h1>
        </div>
        <div class="head-control">          
            <?php echo $__env->make('layout.header_setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </header>

    <div class="body-content">
        <?php echo $__env->make('message_error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('javascript_message_error_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- mobile title -->
        <h1 class="page-title-sm">Introduction Screen List</h1>

        <div class="border-bottom mb-3 pb-3">
            <a href="#" onclick="app_chack(<?php echo e(chack_app_list()); ?>)" class="btn btn-default mw-120">Add</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped" id="example">
                <thead>                               
                <th>Title</th>
                <th>Description</th>
                <th>Image</th>
                <th>Status</th>
                <th>Actions</th>
                </thead>
                <tbody>
                    <?php if($data->count() == 0): ?>
                    <tr>
                        <td colspan="99" class="text-center">No data found.</td>
                    </tr>
                    <?php endif; ?>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>                                    
                        <td><?php echo e($d->title); ?></td>
                        <td><?php echo e($d->description); ?></td>
                        <td>
                            <?php if($d->image): ?>
                            <img src="<?php echo e(url('/')); ?>/<?php echo e($d->image); ?>" height="50">
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($d->status==1): ?>
                            Active
                            <?php else: ?>
                            Inactive
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="btn" href="<?php echo e(route('admin.introduction.edit', [$d->id])); ?>">
                                <img src="<?php echo e(url('/')); ?>/assets/imgs/edit.png" />
                            </a>
                            <a class="btn" href="<?php echo e(route('admin.introduction.delete', [$d->id])); ?>">
                                <img src="<?php echo e(url('/')); ?>/assets/imgs/trash.png" />
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>

<script type="text/javascript">
    function app_chack(app)
    {   
        if(app){
            window.location.href = "<?php echo e(route('admin.introduction.add')); ?>";       
        } else {
            alert("No Any App So Please Create App !!!");
            window.location.href = "<?php echo e(route('admin.app.add')); ?>"; 
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.page-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/admin/introduction/index.blade.php ENDPATH**/ ?>