<?php if(Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show msgHide" role="alert">
    <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php echo e(Session::forget('success')); ?>

<?php endif; ?>
<?php if(Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible fade show msgHide" role="alert">
    <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php echo e(Session::forget('error')); ?>

<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/message_error_success.blade.php ENDPATH**/ ?>