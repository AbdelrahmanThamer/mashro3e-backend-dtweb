<div class="sidebar">
    <div class="side-head">
        <a href="#">
            <img src="<?php echo e(url('/')); ?>/assets/imgs/logo.png" alt="" class="side-logo" />
        </a>
        <button class="btn side-toggle">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
    <ul class="side-menu">
        <li class="<?php echo e((request()->routeIs('admin.dashboard*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/dashboard.png" alt="" />
                <span>Dashboard</span>
            </a>
        </li>  
        <li  class="<?php echo e((request()->routeIs('admin.settings*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.settings')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/settings.png" alt="" />
                <span>Settings</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.app*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.app')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/app.png" alt="" />
                <span>App</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.users*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.users')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/artist.png" alt="" />
                <span>Users</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.introduction*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.introduction')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/pages.png" alt="" />
                <span>Introduction Screen</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.splash_screen*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.splash_screen')); ?>">
                <i class="fa fa-file-image-o menu-icon" aria-hidden="true" style="font-size: 24px;vertical-align:middle"></i>
                <!-- <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/settings.png" alt="" /> -->
                <span>Splash Screen</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.menu*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.menu')); ?>">
                <i class="fa fa-bars menu-icon" aria-hidden="true" style="font-size: 24px;vertical-align:middle"></i>
                <span>Menu</span>
            </a>
        </li>
        <li  class="<?php echo e((request()->routeIs('admin.floating_menu*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.floating_menu')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/categories.png" alt="" />
                <span>Floating Menu</span>
            </a>
        </li>
      <!--   <li  class="<?php echo e((request()->routeIs('admin.social_share*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.social_share')); ?>">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/share.png" alt="" />
                <span>Social Share</span>
            </a>
        </li> -->
        <li  class="<?php echo e((request()->routeIs('admin.messages*')) ? 'active' : ''); ?><?php echo e((request()->routeIs('admin.notification*')) ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.messages')); ?>">                
                <i class="fa fa-comments menu-icon" aria-hidden="true" style="font-size: 24px;vertical-align:middle"></i>
                <span>Messages</span>
            </a>
        </li>
        
        <li>           
            <a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
                <img class="menu-icon" src="<?php echo e(url('/')); ?>/assets/imgs/logout.png" alt="" />
                <span>Logout</span>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</div><?php /**PATH D:\xampp\htdocs\envato\app\dtweb\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>